# 🐾 Dog Life — AI Adventure

A polished browser game built for the **DEV Weekend Challenge: Dog Days Edition**.

## What it is

You play as a dog with 60 seconds to collect five bones and make it home. The game includes:

- Keyboard + mobile touch controls
- Score, timer, happiness and energy systems
- Collectible bones
- Obstacles and a roaming cat
- AI-generated missions with Google Gemini
- ElevenLabs voice narration when an ElevenLabs key is configured
- Offline fallbacks so the game remains playable without API keys
- Responsive UI

## Prize-category integrations

### Google AI
`/api/mission.js` calls the Gemini API to generate short, playable dog missions.

The project uses the Gemini 2.5 Flash-Lite model endpoint and expects:

`GEMINI_API_KEY`

### ElevenLabs
`/api/voice.js` calls ElevenLabs Text-to-Speech to narrate missions and game events.

Environment variables:

`ELEVENLABS_API_KEY`

Optional:

`ELEVENLABS_VOICE_ID`

The game falls back to the browser Speech Synthesis API if ElevenLabs is unavailable.

## Run locally

1. Install Node.js.
2. Install Vercel CLI:
   `npm i -g vercel`
3. In the project directory:
   `vercel dev`
4. Open the local URL shown by Vercel.

## Deploy

This project is structured for Vercel.

1. Push the folder to a new GitHub repository.
2. Import the repository into Vercel.
3. Add `GEMINI_API_KEY` as an environment variable.
4. Add `ELEVENLABS_API_KEY` as an environment variable.
5. Optionally add `ELEVENLABS_VOICE_ID`.
6. Deploy.

Never put API keys directly into `public/game.js` or other client-side files.

## Challenge notes

The game itself is a new project for the DEV Weekend Challenge window. Keep the Git history honest and do not add substantial new functionality after the submission deadline without documenting it.

Suggested DEV tags:

`devchallenge` `weekendchallenge` `googleai` `elevenlabs`

## Google AI Studio Education Track

The separate DEV Google AI Studio Builder track asks for an app using image generation with Imagen. This game currently focuses on Gemini + ElevenLabs for the Dog Days challenge; an Imagen character-generator feature can be added separately if needed for that track.
