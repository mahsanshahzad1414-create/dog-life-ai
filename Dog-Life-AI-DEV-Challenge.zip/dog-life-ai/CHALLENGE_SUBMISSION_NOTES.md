# DEV Submission Checklist

Title:
Dog Life 🐕 — An AI-Powered Dog Adventure

Tags:
- devchallenge
- weekendchallenge
- googleai
- elevenlabs

Prize categories:
- Best Use of Google AI
- Best Use of ElevenLabs

Before publishing:
- [ ] Public GitHub repository
- [ ] Public deployed demo
- [ ] Test game on phone
- [ ] Test game on desktop
- [ ] Confirm Gemini mission appears as "Powered by Google Gemini"
- [ ] Confirm ElevenLabs voice works when API key is configured
- [ ] Capture 2–3 screenshots
- [ ] Explain what was built
- [ ] Explain how Gemini is used
- [ ] Explain how ElevenLabs is used
- [ ] Link demo
- [ ] Link code
- [ ] Publish before the challenge deadline
