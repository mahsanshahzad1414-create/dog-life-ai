export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const apiKey = process.env.GEMINI_API_KEY;
  const fallback = [
    "Sniff out the hidden bone near the garden before time runs out!",
    "Do a victory lap around the park and collect 2 treats.",
    "Find the squeaky toy and bring it back to the dog house.",
    "Chase the red ball, then escape the cat zone!",
    "Patrol the yard and collect 3 bones without hitting a puddle."
  ];

  if (!apiKey) {
    return res.status(200).json({
      mission: fallback[Math.floor(Math.random() * fallback.length)],
      source: "fallback"
    });
  }

  try {
    const prompt = `You are the mission designer for a funny family-friendly browser game called Dog Life.
Generate ONE short playable dog mission in 12 words or fewer.
It must involve collecting, exploring, avoiding, or reaching something.
Return only the mission text. No quotes, bullets, emojis, or explanation.`;

    const r = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" +
      encodeURIComponent(apiKey),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.9, maxOutputTokens: 40 }
        })
      }
    );

    if (!r.ok) throw new Error("Gemini request failed");
    const data = await r.json();
    const mission =
      data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();

    return res.status(200).json({
      mission: mission || fallback[0],
      source: "Google Gemini"
    });
  } catch (e) {
    return res.status(200).json({
      mission: fallback[Math.floor(Math.random() * fallback.length)],
      source: "fallback"
    });
  }
}