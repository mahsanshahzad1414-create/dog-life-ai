const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

let selectedDog = {name:"Buddy", emoji:"🐶"};
let audioOn = true;
let running = false;
let last = 0, timeLeft = 60, score = 0, bones = 0, happiness = 100, energy = 100;
let keys = {};
let missionText = "Collect 5 bones and reach the exit!";
let missionSource = "Built-in starter mission";
let player, boneItems, obstacles, exit, particles, cat;
const canvas = $("#game"), ctx = canvas.getContext("2d");

const W=900,H=560;
const world = {grass:"#75b963", path:"#d9c48b", water:"#56a8d8", tree:"#2f7c4c", dark:"#315d3d"};

$$(".dogChoice").forEach(btn=>{
  btn.onclick=()=>{
    $$(".dogChoice").forEach(x=>x.classList.remove("selected"));
    btn.classList.add("selected");
    selectedDog={name:btn.dataset.dog,emoji:btn.dataset.emoji};
  };
});

$("#soundBtn").onclick=()=>{audioOn=!audioOn;$("#soundBtn").textContent=audioOn?"🔊":"🔇"};
$("#startBtn").onclick=startGame;
$("#againBtn").onclick=startGame;
$("#newMissionBtn").onclick=getMission;
$("#speakBtn").onclick=()=>speak(missionText);

window.addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true; if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(e.key.toLowerCase()))e.preventDefault()});
window.addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
$$(".mobileControls button").forEach(b=>{
  const k=b.dataset.key.toLowerCase();
  b.addEventListener("pointerdown",e=>{e.preventDefault();keys[k]=true});
  b.addEventListener("pointerup",e=>{e.preventDefault();keys[k]=false});
  b.addEventListener("pointerleave",()=>keys[k]=false);
});

function startGame(){
  $("#startScreen").classList.remove("active");
  $("#endScreen").classList.remove("active");
  $("#gameScreen").classList.add("active");
  timeLeft=60;score=0;bones=0;happiness=100;energy=100;running=true;
  player={x:90,y:470,r:20,speed:230};
  exit={x:820,y:70,w:52,h:70};
  boneItems=[
    {x:170,y:105,got:false},{x:355,y:145,got:false},{x:610,y:110,got:false},
    {x:720,y:355,got:false},{x:425,y:455,got:false}
  ];
  obstacles=[
    {x:250,y:270,w:110,h:28,type:"bench"},{x:520,y:250,w:38,h:100,type:"tree"},
    {x:705,y:180,w:35,h:35,type:"hole"},{x:140,y:320,w:35,h:35,type:"hole"},
    {x:600,y:440,w:100,h:25,type:"bench"}
  ];
  cat={x:760,y:470,r:18,dx:-1};
  particles=[];
  updateHUD();
  getMission();
  speak("Woof! My adventure begins!");
  last=performance.now();
  requestAnimationFrame(loop);
}

function loop(now){
  if(!running)return;
  const dt=Math.min((now-last)/1000,.035); last=now;
  update(dt); draw();
  requestAnimationFrame(loop);
}

function update(dt){
  timeLeft-=dt;
  if(timeLeft<=0){timeLeft=0;finish(false);return}
  let dx=0,dy=0;
  if(keys["arrowleft"]||keys["a"])dx--;
  if(keys["arrowright"]||keys["d"])dx++;
  if(keys["arrowup"]||keys["w"])dy--;
  if(keys["arrowdown"]||keys["s"])dy++;
  if(dx||dy){
    const len=Math.hypot(dx,dy); dx/=len;dy/=len;
    const speed=player.speed*(energy>10?1:.62);
    const nx=player.x+dx*speed*dt,ny=player.y+dy*speed*dt;
    if(!blocked(nx,ny)){player.x=nx;player.y=ny;energy=Math.max(0,energy-5*dt)}
    else happiness=Math.max(0,happiness-4*dt);
  }else energy=Math.min(100,energy+7*dt);
  player.x=Math.max(24,Math.min(W-24,player.x));player.y=Math.max(24,Math.min(H-24,player.y));

  boneItems.forEach(b=>{
    if(!b.got&&dist(player,b)<30){b.got=true;bones++;score+=100;happiness=Math.min(100,happiness+5);burst(b.x,b.y);speak(["Yum!","Bone acquired!","Best. Day. Ever!"][bones%3]);}
  });
  if(dist(player,cat)<38){score=Math.max(0,score-25);happiness=Math.max(0,happiness-12);cat.x=780;cat.y=80;speak("CAT! Retreat!");}
  if(player.x>exit.x-10&&player.x<exit.x+exit.w+10&&player.y>exit.y-10&&player.y<exit.y+exit.h+10&&bones>=5){score+=500;finish(true);return}
  cat.x += cat.dx*55*dt; if(cat.x<680||cat.x>820)cat.dx*=-1;
  particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt});
  particles=particles.filter(p=>p.life>0);
  updateHUD();
}

function blocked(x,y){
  for(const o of obstacles){
    const cx=Math.max(o.x,Math.min(x,o.x+o.w)),cy=Math.max(o.y,Math.min(y,o.y+o.h));
    if(Math.hypot(x-cx,y-cy)<player.r+4)return true;
  }
  return false;
}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}

function finish(win){
  running=false;
  $("#gameScreen").classList.remove("active");$("#endScreen").classList.add("active");
  $("#resultIcon").textContent=win?"🏆":"🌙";
  $("#resultTitle").textContent=win?"GOOD DOG! YOU MADE IT HOME!":"SUNSET ARRIVED!";
  $("#resultText").textContent=win
    ? `${selectedDog.name} completed the adventure with ${score} points.`
    : `${selectedDog.name} ran out of time. The backyard wins this round.`;
  $("#finalScore").textContent=score;
  $("#finalBones").textContent=`${bones}/5`;
  $("#finalTime").textContent=`${Math.ceil(timeLeft)}s`;
  speak(win?"I did it! Best dog ever!":"Oh no... bedtime already?");
}

function updateHUD(){
  $("#bones").textContent=`${bones}/5`;
  $("#score").textContent=score;
  $("#time").textContent=Math.ceil(timeLeft);
  $("#happyMeter").style.width=happiness+"%";
  $("#energyMeter").style.width=energy+"%";
}

async function getMission(){
  $("#missionText").textContent="Gemini is sniffing for a mission…";
  try{
    const r=await fetch("/api/mission",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
    const data=await r.json();
    missionText=data.mission||"Collect 5 bones and find the exit!";
    missionSource=data.source==="Google Gemini"?"Powered by Google Gemini":"Built-in fallback";
  }catch{
    missionText=["Find a hidden bone near the trees!","Explore the yard and collect 2 treats!","Avoid the cat and reach the garden!"][Math.floor(Math.random()*3)];
    missionSource="Offline fallback";
  }
  $("#missionText").textContent=missionText;
  $("#missionSource").textContent=missionSource;
  if(audioOn)speak(missionText);
}

async function speak(text){
  if(!audioOn)return;
  try{
    const r=await fetch("/api/voice",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text})});
    if(r.ok&&r.status!==204){
      const blob=await r.blob(); new Audio(URL.createObjectURL(blob)).play().catch(()=>{});
      return;
    }
  }catch{}
  if("speechSynthesis" in window){
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(text);u.pitch=1.35;u.rate=1.08;u.volume=.85;speechSynthesis.speak(u);
  }
}

function burst(x,y){
  for(let i=0;i<12;i++)particles.push({x,y,vx:(Math.random()-.5)*120,vy:(Math.random()-.5)*120,life:.7});
}

function draw(){
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle=world.grass;ctx.fillRect(0,0,W,H);
  // path
  ctx.fillStyle=world.path;ctx.beginPath();ctx.moveTo(0,410);ctx.quadraticCurveTo(300,300,500,360);ctx.quadraticCurveTo(680,420,900,270);ctx.lineTo(900,350);ctx.quadraticCurveTo(680,500,470,420);ctx.quadraticCurveTo(260,360,0,470);ctx.fill();
  // water
  ctx.fillStyle=world.water;ctx.fillRect(0,0,W,58);
  // fence
  ctx.strokeStyle="#e7d5a4";ctx.lineWidth=9;for(let x=0;x<W;x+=32){ctx.beginPath();ctx.moveTo(x,4);ctx.lineTo(x,58);ctx.stroke()}
  // trees
  [[80,110],[820,120],[80,260],[850,420],[330,80]].forEach(([x,y])=>drawTree(x,y));
  // exit
  ctx.fillStyle="#5b3a2a";ctx.fillRect(exit.x,exit.y,exit.w,exit.h);
  ctx.fillStyle="#f4d26a";ctx.fillRect(exit.x+10,exit.y+12,exit.w-20,exit.h-12);
  ctx.fillStyle="#241d24";ctx.font="bold 11px system-ui";ctx.textAlign="center";ctx.fillText("HOME",exit.x+26,exit.y+8);
  ctx.font="22px serif";ctx.fillText("🚪",exit.x+26,exit.y+44);
  // obstacles
  obstacles.forEach(o=>{
    if(o.type==="tree"){drawTree(o.x+19,o.y+20)}
    else if(o.type==="hole"){ctx.fillStyle="#233225";ctx.beginPath();ctx.ellipse(o.x+17,o.y+17,19,12,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#0c1117";ctx.beginPath();ctx.ellipse(o.x+17,o.y+17,12,7,0,0,Math.PI*2);ctx.fill()}
    else {ctx.fillStyle="#754a2e";ctx.fillRect(o.x,o.y,o.w,o.h);ctx.fillStyle="#c98a4c";ctx.fillRect(o.x-5,o.y-7,o.w+10,7)}
  });
  // bones
  boneItems.forEach(b=>{if(!b.got)drawBone(b.x,b.y)});
  // cat
  ctx.font="31px serif";ctx.textAlign="center";ctx.fillText("🐈",cat.x,cat.y+11);
  // player
  ctx.beginPath();ctx.fillStyle="#fff1d6";ctx.arc(player.x,player.y,25,0,Math.PI*2);ctx.fill();
  ctx.font="34px serif";ctx.fillText(selectedDog.emoji,player.x,player.y+12);
  // particles
  particles.forEach(p=>{ctx.globalAlpha=Math.max(0,p.life/.7);ctx.fillStyle="#fff3a1";ctx.beginPath();ctx.arc(p.x,p.y,4,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1});
  // labels
  ctx.fillStyle="#162016cc";ctx.font="700 12px system-ui";ctx.textAlign="left";ctx.fillText("🐕 DOG PARK",18,85);
  ctx.fillText("🏠 GET HOME AFTER 5 BONES",680,535);
}
function drawTree(x,y){
  ctx.fillStyle="#7b5436";ctx.fillRect(x-6,y+12,12,34);
  ctx.fillStyle="#2f7c4c";ctx.beginPath();ctx.arc(x,y,28,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#4e9a5d";ctx.beginPath();ctx.arc(x-18,y+5,19,0,Math.PI*2);ctx.fill();
}
function drawBone(x,y){
  ctx.save();ctx.translate(x,y);ctx.rotate(-.35);ctx.strokeStyle="#fff3d0";ctx.lineWidth=9;ctx.lineCap="round";
  ctx.beginPath();ctx.moveTo(-13,0);ctx.lineTo(13,0);ctx.stroke();
  ctx.fillStyle="#fff3d0";[[-15,-5],[-15,5],[15,-5],[15,5]].forEach(([a,b])=>{ctx.beginPath();ctx.arc(a,b,6,0,Math.PI*2);ctx.fill()});ctx.restore();
}
